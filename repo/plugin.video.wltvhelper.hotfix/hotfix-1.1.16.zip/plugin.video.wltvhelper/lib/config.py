# -*- coding: utf-8 -*-

import xbmcaddon, sys, os

if sys.version_info[0] >= 3:
    import xbmcvfs
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

ADDON = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_USER_PATH = ADDON.getAddonInfo("profile")
ADDON_VERSION   = ADDON.getAddonInfo("version")
ADDON_PATH_ROOT = translatePath("special://home/addons/")


def getSetting(name):
    value = ADDON.getSetting(name)
    if value == "true":
        value = True
    elif value == "false":
        value = False
    else:
        try:
            value = int(value)
        except ValueError:
            pass
    return value


def setSetting(name, value):
    if value == True:
        value = "true"
    elif value == False:
        value = "false"
    else:
        value = str(value)
    ADDON.setSetting(name, value)


def openSettings():
    ADDON.openSettings()


def getAddonInfo(name):
    return ADDON.getAddonInfo(name)


def quality(qualities):
    resolutions = [1080, 720, 480]
    resolution = resolutions[int(getSetting("resolutions"))]
    selected = [min(range(len(qualities)), key=lambda i: abs(int(qualities[i]) - resolution))][0]
    return selected


def getString(ID):
    return ADDON.getLocalizedString(ID)


def isDEV():
    return os.path.isdir(os.path.join(ADDON_PATH, ".git"))
