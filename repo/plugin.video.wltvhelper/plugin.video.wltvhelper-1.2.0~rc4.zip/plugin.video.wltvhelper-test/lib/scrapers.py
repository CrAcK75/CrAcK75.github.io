# -*- coding: utf-8 -*-
import re

def findSingleMatch(data, pattern, index=0):
    try:
        if index == 0:
            matches = re.search(pattern, data, flags=re.DOTALL)
            if matches:
                if len(matches.groups()) == 1:
                    return matches.group(1)
                elif len(matches.groups()) > 1:
                    return matches.groups()
                else:
                    return matches.group()
            else:
                return ""
        else:
            matches = re.findall(pattern, data, flags=re.DOTALL)
            return matches[index]
    except:
        return ""


def findMultipleMatches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)
