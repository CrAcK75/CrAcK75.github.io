# -*- coding: utf-8 -*-
# Module: WorldLiveTV
# Author: CrAcK75
# Created on: 01/02/2022
#

import os
import re
import sys
import random
import json
from enum import Enum
from lib import logger

IsPY3 = True if sys.version_info[0] >= 3 else False

if IsPY3:
    from urllib import request
else:
    import urllib as request
    import imp as importlib

    importlib.reload(sys)
    sys.setdefaultencoding("utf8")


NOT_DIGIT_OR_NUMERIC = "[UNK]"
ABC="abcdefghijklmnopqrstuvwxyz"

TAG_TVG_NAME = "tvg-name"
TAG_TVG_CHNO = "tvg-chno"
TAG_TVG_ID   = "tvg-id"
TAG_TVG_LOGO = "tvg-logo"
TAG_GROUP_TITLE = "group-title"


class M3UStreamType(Enum):
    LIVE   = 0
    MOVIES = 1
    SERIES = 2

    def __str__(self):
        return self.name

class M3UStreamSubGroup(Enum):
    ABC   = 0
    GROUP = 1

    def __str__(self):
        return self.name

class M3USearchField(Enum):
    Title     = 1
    TvgName   = 2
    TvgChNo   = 3
    TvgId     = 4
    TvgLogo   = 5
    TvgGroup  = 6
    Link      = 7

    def __str__(self):
        return self.name

class M3USearchType(Enum):
    Equals     = 0
    StartsWith = 1
    EndsWith   = 2
    Contains   = 3

    def __str__(self):
        return self.name

class M3UItem():
    Title     = ""
    TvgName   = ""
    TvgChNo   = ""
    TvgId     = ""
    TvgLogo   = ""
    TvgGroup  = ""
    Link      = ""
    IsLive    = False
    IsFilm    = False
    IsSerie   = False

    def __init__(self, lineInfo="", url="", dic={}):
        for k, v in dic.items():
            self.__setattr__(k, v)

        if(lineInfo and url):
            try:
                m = re.search( TAG_TVG_NAME + '="(.*?)"', lineInfo)
                name = m.group(1) if m else ""
                m = re.search( TAG_TVG_CHNO + '="(.*?)"', lineInfo)
                number = m.group(1) if m else ""
                m = re.search( TAG_TVG_ID   + '="(.*?)"', lineInfo)
                tvgid = m.group(1) if m else ""
                m = re.search( TAG_TVG_LOGO + '="(.*?)"', lineInfo)
                logo = m.group(1) if m else ""
                m = re.search( TAG_GROUP_TITLE + '="(.*?)"', lineInfo)
                group = m.group(1) if m else ""
                m = re.search("(?!.*=\",?.*\")[,](.*?)$", lineInfo)
                title = m.group(1)

                isFilm = "/movie/" in url.lower()
                isSerie = "/series/" in url.lower()

                self.__setattr__("Title"   , title .strip())
                self.__setattr__("TvgName" , name  .strip())
                self.__setattr__("TvgChNo" , number.strip())
                self.__setattr__("TvgId"   , tvgid .strip())
                self.__setattr__("TvgLogo" , logo  .strip())
                self.__setattr__("TvgGroup", group .strip())
                self.__setattr__("Link"    , url   ) #os.path.basename(url))
                self.__setattr__("IsFilm"  , isFilm)
                self.__setattr__("IsSerie" , isSerie)
                self.__setattr__("IsLive"  , not isSerie and not isFilm)

            except Exception as ex :
                logger.error(ex)
                logger.error(lineInfo)

class M3UParser:
    exclusion = list()
    groupsFilter = list()
    lstGroupCleanup = list()
    isValid = False

    def __init__(self, logging):
        self.lines     = list()
        self.items     = list()
        self.selection = list()
        self.logging   = logging

    # Load the file from the given url
    def loadM3U(self, url, filename):
        currentDir = os.path.dirname(os.path.realpath(__file__))
        if not filename:
            filename = "~~temp.dat"

        try:
            filename = os.path.join(currentDir, filename)
            request.urlretrieve(url, filename)
            self.readM3U(filename)
        except Exception as ex:
            logger.error("Cannot download anything from the provided url")
            logger.error(ex)

    # Read the file from the given path
    def readM3U(self, filename):
        self.filename = filename
        self.__parseFile()
        #if self.lstGroupCleanup:
        #    self.CleanUp(M3USearchField.TvgGroup, self.lstGroupCleanup)


    # Read all file lines
    def __parseFile(self):
        self.items = list()

        fileContent = None

        try:
            if IsPY3:
                fileContent = open(self.filename, encoding="utf8")
            else:
                fileContent = open(self.filename)

            if fileContent:
                strFileContentLines = fileContent.read()

                if(strFileContentLines[:7].lower() == "#extm3u"):
                    fileContent.seek(0, 0)
                    self.lines = [ line.rstrip("\n") for line in fileContent ]
                    linesCount = len(self.lines)

                    for n in range(linesCount):
                        line = self.lines[n]
                        if line.strip() != "" and line[0] == "#":
                            self.__manageLine(n)
                else:
                    jsonData = json.loads(strFileContentLines)
                    self.items = [ M3UItem(dic=D) for D in jsonData ]
                self.isValid = True
            else:
                logger.error("No file content in provided file: {}".format(self.filename))
        except Exception as ex :
            logger.error(ex)
            self.items = list()

        self.lines = list()


    def __manageLine(self, n):
        linesCount = len(self.lines)
        lineInfo = self.lines[n]
        lineLink = ""

        while (not (lineLink.startswith("http") or lineLink.startswith("plugin"))) and n < linesCount - 1:
            n += 1
            lineLink = self.lines[n]
            if lineLink.startswith("#EXTINF"):
                n -= 1
                return

            for x in self.exclusion:
                if x in lineLink:
                    return

            if lineInfo.startswith("#EXTINF"):
                try:
                    item = M3UItem(lineInfo, lineLink)
                    if(item):
                        self.items.append(item) 

                except Exception as ex :
                        logger.error(ex)
                        logger.error(lineInfo)

    def saveM3U(self, fileName):
        lines = list()
        lines.append("#EXTM3U")
        lines.append("")

        extinf = '#EXTINF:-1 tvg-chno="{}" tvg-id="{}" tvg-name="{}" tvg-logo="{}" group-title="{}",{}'

        if not self.selection:
            self.selection = self.items

        for x in self.selection:
            group = x.TvgGroup if x.TvgGroup else "[Unknown]"
            link  = x.Link if x.Link else "https://foo_.com"
            lines.append(extinf.format(x.TvgChNo, x.TvgId, x.TvgName, x.TvgLogo, group, x.Title))
            lines.append(link)

        with open(fileName, "w", encoding="utf8") as f:
            f.write('\n'.join(lines))

    def saveM3UJ(self, fileName):
        if not self.selection:
            self.selection = self.items

        with open(fileName, "w", encoding="utf8") as f:
            f.write(json.dumps(self.selection, default = lambda x: x.__dict__))

    # Get selected type channels of the list (98% of pannels list)
    def getItems(self, streamType: M3UStreamType, searchField: M3USearchField = None, searchType: M3USearchType = None, search = "") -> list:
        self.selection = list()

        # Get only live channel of the list (98% of pannels list)
        if streamType == M3UStreamType.LIVE: 
            self.selection = list(filter(lambda item: item.IsLive or item.TvgGroup.lower().startswith("live"), self.items))
        
        # Get only Film VOD of the list (98% of pannels list)
        elif streamType == M3UStreamType.MOVIES: 
            self.selection = list(filter(lambda item: item.IsFilm or (not item.IsLive and (item.TvgGroup.lower().startswith("movie") or item.TvgGroup.lower().startswith("film"))), self.items))
        
        # Get only SeriesTV VOD of the list (98% of pannels list)
        elif streamType == M3UStreamType.SERIES: 
            self.selection = list(filter(lambda item: item.IsSerie or (not item.IsLive and (item.TvgGroup.lower().startswith("serie"))), self.items))

        if search and searchField != None:
            fieldOfSearch = str(searchField)
            if (search == NOT_DIGIT_OR_NUMERIC.lower()):
                if(searchField == M3USearchField.TvgGroup):
                    search = ""
                elif(searchField == M3USearchField.TvgName):
                    search = list()
                    search[:0]=ABC
                    self.selection = list(filter(lambda item: not item.TvgName.lower().startswith(tuple(search)), self.selection))
            else:
                if not isinstance(search, list):
                    search = [search]
                    search  = [x.lower() for x in search]

                if searchType == M3USearchType.Equals:
                    self.selection = list(filter(lambda item: all(f == item.__dict__.get(fieldOfSearch, "").lower() for f in search), self.selection))
                elif searchType == M3USearchType.StartsWith:
                    self.selection = list(filter(lambda item: item.__dict__.get(fieldOfSearch, "").lower().startswith(tuple(search)), self.selection))
                elif searchType == M3USearchType.EndsWith:
                    self.selection = list(filter(lambda item: item.__dict__.get(fieldOfSearch, "").lower().endswith(tuple(search)), self.selection))
                elif searchType == M3USearchType.Contains:
                    self.selection = list(filter(lambda item: all(f in item.__dict__.get(fieldOfSearch, "").lower() for f in search), self.selection))

        if self.groupsFilter:
            self.selection = list(filter(lambda item: item.TvgGroup in self.groupsFilter, self.selection))

        return self.selection

    # Getter for the groups
    def getGroups(self, streamType: M3UStreamType, filterGroups=[]) -> list:
        res = list()

        for item in self.getItems(streamType):
            g = item.TvgGroup

            if (g not in res):
                if(filterGroups and g in filterGroups) or (not filterGroups):
                    res.append(g)
                #elif (not filterGroups):
                #    res.append(g)

        res.sort()
        return res

    def CleanUpGroups(self, lstCleanup: list = []):
        import re
        #for x in lstCleanup:
        #    self.items = [ re.sub(f"^{x}", "", item.TvgGroup, flags=re.IGNORECASE).strip().strip("-").strip() for item in self.items ]
        
        for idx in range(len(self.selection)):
            for x in lstCleanup:
                self.items[idx].TvgGroup = re.sub(f"^{x}", "", self.items[idx].TvgGroup, flags=re.IGNORECASE).strip().strip("-").strip()

    # Get only live channel of the list (98% of pannels list)
    def getLive(self) -> list:
        return self.getItems(M3UStreamType.LIVE)

    # Get only Film VOD of the list (98% of pannels list)
    def getFilms(self) -> list:
        return self.getItems(M3UStreamType.MOVIES)

    # Get only SeriesTV VOD of the list (98% of pannels list)
    def getSeries(self) -> list:
        return self.getItems(M3UStreamType.SERIES)

    # Get only SerieTV VOD of a group
    def getSerieFromGroup(self, groupName) -> list:
        return self.getItems(M3UStreamType.SERIES, M3USearchField.TvgGroup, M3USearchType.Equals, groupName)

    # Get only Films VOD starting with alpha
    def getFilmFromGroup(self, groupName) -> list:
        return self.getItems(M3UStreamType.MOVIES, M3USearchField.TvgGroup, M3USearchType.Equals, groupName)
