# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://play.xdevel.com"


def play(search):
    res = BroadcasterResult()
    url = ""

    data = requests.get("{}/{}".format(HOST, search)).text
    matches = scrapers.find_multiple_matches(data, r"source\":\"([^\"]+)[^*]+PLAYER_WAS\s?=\s?'([^']+)") #source\":\"([^\"]+)|PLAYER_WAS\s?=\s?'([^']+)")

    for urltemp, key in matches:
        url = "{}?wmsAuthSign={}".format(urltemp, key)
        break

    if url:
        res.Url = url
        #res["manifest"] = "hls"

    return res
