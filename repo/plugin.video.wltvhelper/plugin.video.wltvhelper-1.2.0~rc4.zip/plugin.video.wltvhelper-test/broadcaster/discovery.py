# -*- coding: utf-8 -*-

import requests
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult

mpd = config.getSetting("mpd")

API = "https://disco-api.discoveryplus.it"
token = requests.get(API + "/token?realm=dplayit").json()["data"]["attributes"]["token"]

headers = {
    "User-Agent": utils.USER_AGENT,
    "Referer": "https://discoveryplus.it",
    "Cookie": "st=" + token,
}


if not utils.IsPY3:
    mpd = False  # temporaneamente disattivato per bug di IA


def play(search):
    res = BroadcasterResult()
    id = ""

    _json = requests.get(API + "/cms/collections/web-footer?include=default", headers=headers).json()["included"]

    for key in _json:
        if (key["type"] == "channel"
            and key.get("attributes", {}).get("hasLiveStream", "")
            and "Free" in key.get("attributes", {}).get("packages", [])
            and search == key["attributes"]["name"]):
            id = key["id"]
            break

    if id:
        data = (
            requests.get("{}/playback/v2/channelPlaybackInfo/{}?usePreAuth=true".format(API, id), headers=headers)
            .json()
            .get("data", {})
            .get("attributes", {})
        )

        if data["protection"].get("drm_enabled", True) and mpd:
            res.Url = data["streaming"]["dash"]["url"]
            res.ManifestType = "mpd"
            res.LicenseKey = (
                data["protection"]["schemes"]["widevine"]["licenseUrl"]
                + "|PreAuthorization="
                + data["protection"]["drmToken"]
                + "|R{SSM}|"
            )
            res.LicenseType = "com.widevine.alpha"
        else:
            res.Url = data["streaming"]["hls"]["url"]
            res.ManifestType = "hls"

    return res
