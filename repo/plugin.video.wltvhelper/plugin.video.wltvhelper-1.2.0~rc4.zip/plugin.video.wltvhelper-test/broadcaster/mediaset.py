# -*- coding: utf-8 -*-
from urllib3.exceptions import InsecureRequestWarning
import xbmcgui
import uuid, requests
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

mpd = config.getSetting("mpd")

HOST = "https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true"
LOGIN_URL = "https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0"
LICENSE_URL = "https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|"

clientId = str(uuid.uuid1())
#clientId = "f66e2a01-c619-4e53-8e7c-4761449dd8ee"

loginData = {
    "client_id": clientId,
    "platform": "pc",
    "appName": "web//mediasetplay-web/5.1.497-plus-101613c",
}


def play(search):
    res = BroadcasterResult()

    tkRes = requests.post(LOGIN_URL, json=loginData, verify=False)
    token = tkRes.json()["response"]["beToken"]
    url = ""
    pid = ""

    strmFormat = "dash+xml" if mpd else "x-mpegURL"

    # get Json
    items = requests.get(HOST).json()["entries"]

    # search
    for item in items:
        if search.startswith("$"):
            _search = "$" + item["callSign"]
        else:
            _search = item["title"]

        if item.get("tuningInstruction") and _search == search:

            for key in item["tuningInstruction"]["urn:theplatform:tv:location:any"]:
                if key["format"] == "application/{}".format(strmFormat):
                    try:
                        url = key["publicUrls"][0]
                        if (mpd and "widevine" in key["assetTypes"]):
                            pid = key["releasePids"][0]
                            #logger.debug("url:", url)
                            #logger.debug("pid:", pid)
                            break
                        elif not mpd:
                            break
                    except:
                        logger.error("No PublicUrls for", search, "with format", strmFormat)

        if url:
            # set manifest for IA
            res.ManifestType = "hls"

            if mpd:
                res.ManifestType = "mpd"
                res.ManifestUpdateParameter = "full"
                if pid:
                    res.LicenseKey = LICENSE_URL.format(pid=pid, token=token)

            url = requests.get(url).url if "theplatform" in url else url
            url = "{}|user-agent={}".format(url, utils.USER_AGENT)
            res.StreamHeader = "user-agent={}".format(utils.USER_AGENT)
            res.Url = url
            break
        else:
            logger.error("No url found for", search)

    return res
