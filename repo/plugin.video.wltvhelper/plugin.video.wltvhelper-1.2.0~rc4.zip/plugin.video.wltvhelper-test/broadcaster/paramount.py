# -*- coding: utf-8 -*-
import requests, json
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.mtv.it"


def play(search):
    res = BroadcasterResult()
    url = ""

    urlChannel = HOST + "/diretta-tv/1iwm9n"

    data = requests.get(urlChannel).text
    jsonData = scrapers.findSingleMatch(data, r"window\.__DATA__\s=\s([^;]+)")
    jsonData = json.loads(jsonData)

    mgid = ""
    for child1 in jsonData["children"]:
        if(child1["type"] == "MainContainer"):
            for child2 in child1["children"]:
                if(child2["type"] == "Box"):
                    for child3 in child2["children"]:
                        if(child3["type"] == "VideoPlayer"):
                            mgid = child3["props"]["media"]["video"]["config"]["uri"]
                            break
    if(mgid):
        urlChannel = "https://media.mtvnservices.com/pmt/e1/access/index.html?uri={}&configtype=edge&ref={}".format(mgid, urlChannel)
        jsonData = requests.get(urlChannel).json()
        urlData = jsonData["feed"]["items"][0]["group"]["content"].replace("&device={device}", "&format=json&acceptMethods=hls&tveprovider=null")

        url = requests.get(urlData).json()["package"]["video"]["item"][0]["rendition"][0]["src"]

    if(url):
        res.Url = url
        # res.ManifestType = "hls"

    return res
