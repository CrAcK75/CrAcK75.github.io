# -*- coding: utf-8 -*-

import requests
from lib import config, logger
from lib.broadcaster_result import BroadcasterResult

API = "https://player-api.new.livestream.com"


def play(search):
    res = BroadcasterResult()

    accountId = search.split("$")[0]
    eventId   = search.split("$")[1]

    url = ""
    url = requests.get("{}/accounts/{}/events/{}/stream_info".format(API, accountId, eventId)).json()["secure_m3u8_url"]

    if url:
        res.Url = url
        res.ManifestType = "hls"

    return res
