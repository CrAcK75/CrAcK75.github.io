# -*- coding: utf-8 -*-

import requests
from lib import utils

headers = {
    "user-agent": utils.USER_AGENT,
    "accept": "*/*",
    "accept-language": "en,en-US;q=0.9,it;q=0.8",
    "origin": "https://www.redbull.com",
    "referer": "https://www.redbull.com/",
}


def play(search):
    url = ""
    tokenurl = "https://api.redbull.tv/v3/session?os_family=http"
    strtoken = requests.get(tokenurl, headers=headers, verify=False).json()["token"]
    url = "https://dms.redbull.tv/v3/linear-borb/%s/playlist.m3u8" % strtoken

    return url
