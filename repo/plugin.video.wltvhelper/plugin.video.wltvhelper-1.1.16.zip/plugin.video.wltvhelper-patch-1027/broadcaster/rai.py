# -*- coding: utf-8 -*-

import requests
from lib import logger

def play(search):
    res = {}
    url = ''
    requrl = 'https://www.raiplay.it/dirette.json'
    json = requests.get(requrl).json()['contents']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['content_url']
            break

    if url:
        res['url'] = requests.get(url).url if "relinkerServlet" in url else url

        if not ".mp4" in url:
            res['manifest'] = 'hls'

    return res
