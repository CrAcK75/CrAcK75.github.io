# -*- coding: utf-8 -*-
import requests
from lib import scrapers

BASE_URL = 'https://sportitalia.com/{}/'
CHANNELS = {
    'sihd': 'sportitalia-hd-live',
    'calcio': 'si-solocalcio-hd',
    'motori': 'si-motori-hd',
    'live24': 'silive24-hd'
}

def play(search):
    url = ''

    if search in CHANNELS:
        requrl = BASE_URL.format(CHANNELS[search])
        data = requests.get(requrl).text
        url = scrapers.find_single_match(data, r"source\s*=\s?'([^']+)")

    return url
