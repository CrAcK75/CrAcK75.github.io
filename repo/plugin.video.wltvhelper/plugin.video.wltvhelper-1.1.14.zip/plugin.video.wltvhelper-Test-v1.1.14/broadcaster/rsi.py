# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, config, logger

headers = {
    'Host': 'srg.live.ott.irdeto.com',
    'Content-Type': '',
    #'Content-Type': 'application/json',
    #'Content-Type': 'application/octet-stream',
    #'Connection': 'keep-alive',
    #'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
    #'Origin': 'https://www.rsi.ch',
    #'Referer': 'https://www.rsi.ch/',
    #'Accept': '*/*',
    #'Accept-Language': 'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
    #'Accept-Encoding': 'gzip, deflate, br',
    #'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"',
    #'sec-ch-ua-mobile': '?0',
    #'Sec-Fetch-Site': 'cross-site',
    #'Sec-Fetch-Mode': 'cors',
    #'Sec-Fetch-Dest': 'empty',
}

baseurl = 'https://il.srgssr.ch/integrationlayer/2.0/mediaComposition/byUrn/%s.json?onlyChapters=false&vector=portalplay'

mpd = config.getSetting('mpd')
#if not utils.PY3():
mpd = False #temporaneamente disattivato per bug di IA

protocol = 'DASH' if mpd else 'HLS'
drmType = 'WIDEVINE' if mpd else 'FAIRPLAY'

def play(search):
    res = {}
    license_url = ''
    
    jsonData = requests.get('https://www.rsi.ch/play/v3/api/rsi/production/tv-livestreams').json()['data']

    for item in jsonData:
        if search == item['title']:
            livestreamUrn = item['livestreamUrn']
            urlStreams = baseurl%livestreamUrn
            chapterList = requests.get(urlStreams).json()['chapterList']
            
            for resourceList in chapterList[0]['resourceList']:
                if (resourceList['protocol'] == protocol):
                    _found = resourceList
                    break
            
            if (_found):
                res['url'] = _found['url']

                for drm in _found['drmList']:
                    if (drm['type'] == drmType):
                        license_url = drm['licenseUrl']
                        break

    res['manifest'] = 'mpd' if mpd else 'hls'
    licH = '&'.join(['%s=%s' % (name, value) for (name, value) in headers.items()])
    lic = '%s|%s|R{SSM}|'%(license_url, licH)
    
    res['key'] = lic
    res['update_parameter'] = 'full'
    
    return res