# Module: main
# Author: ElSupremo
# Created on: 22.02.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import logging
import xbmcgui
import xbmcplugin
import xbmcaddon
import json

from urllib.parse import urlencode, parse_qsl

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

addon_id = 'plugin.video.mandrakodi19'
selfAddon = xbmcaddon.Addon(id=addon_id)

def getSource():
    startUrl = selfAddon.getSetting("baseUrl")
    strSource = makeRequest(startUrl)
    jsonToItems(strSource)

def getExternalJson(strPath):
    strSource = makeRequest(strPath)
    jsonToItems(strSource)

def jsonToItems(strJson):
    dataJson = json.loads(strJson)
    xbmcplugin.setContent(_handle, 'videos')
    for item in dataJson["items"]:
        titolo = "NO TIT"
        thumb = "https://www.andreisfina.it/wp-content/uploads/2018/12/no_image.jpg"
        fanart = "https://www.andreisfina.it/wp-content/uploads/2018/12/no_image.jpg"
        genre = "generic"
        info = ""
        link = ""
        extLink = False
        extLink2 = False
        is_folder = False
        if 'title' in item:
            titolo = item["title"]
        
        if 'thumbnail' in item:
            thumb = item["thumbnail"]

        if 'fanart' in item:
            fanart = item["fanart"]

        if 'info' in item:
            info = item["info"]

        if 'genre' in item:
            genre = item["genre"]

        if 'link' in item:
            link = item["link"]

        if 'externallink' in item:
            extLink = True
            is_folder = True
            link = item["externallink"]

        if 'externallink2' in item:
            extLink2 = True
            is_folder = True
            link = item["externallink2"]

        list_item = xbmcgui.ListItem(label=titolo)
        list_item.setInfo('video', {'title': titolo,
                                    'genre': genre,
                                    'mediatype': 'video'})
        list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
        
        url = ""
        if extLink == True:
            url = get_url(action='getExtData', extUrl=link)
        elif extLink2 == True:
            url = get_url(action='getExtData2', extUrl=link)
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video=link)

        logging.warning("Add Item")
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


        
def makeRequest(url, hdr=None):
    import urllib.request
    pwd = selfAddon.getSetting("password")
    if hdr is None:
        ua = "MandraKodi@@"+pwd
        hdr = {"User-Agent" : ua}
    req = urllib.request.Request(url, headers=hdr)
    response = urllib.request.urlopen(req)
    html = response.read()
    #html = requests.get(url, headers).text
    return html

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'getExtData':
            # Display the list of videos in a provided category.
            getExternalJson(params['extUrl'])
        elif params['action'] == 'getExtData2':
            keyboard = xbmc.Keyboard('','Insert string')
            keyboard.doModal()
            if not (keyboard.isConfirmed() == False):
                userInput = keyboard.getText()
                strUrl=params['extUrl']+userInput
                getExternalJson(strUrl)
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        logging.warning("=== ADDON START ===")
        getSource()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
