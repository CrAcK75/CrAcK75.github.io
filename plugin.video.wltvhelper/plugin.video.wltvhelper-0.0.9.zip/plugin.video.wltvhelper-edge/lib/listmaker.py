# -*- coding: utf-8 -*-
import xbmc, xbmcgui, json
from lib import config, logger, utils

remoteLists = utils.apiRequester('/all/groups.json')
setting = config.getSetting(utils.PARAM_LIST_NAME)

MAKER = 100
LIST = 200
GROUPS = 300

BACK = 400
OPTIONS = 201
MU = 101
MD = 102
DELETE = 103
EXIT = 10
BACKSPACE = 92

class ListMaker(xbmcgui.WindowXMLDialog):
    def start(self, windowType, param):
        self.windowType = windowType # integer of MAKER, LIST, GROUPS
        self.param = param
        self.setting = json.loads(setting) if setting else []
        self.Choose = {}
        self.Groups = []
        self.doModal()
        if self.windowType == LIST: return self.Choose
        elif self.windowType == GROUPS: return self.Groups

    def onInit(self):
        self.list = []
        self.List = self.getControl(self.windowType)

        # Main Dialog
        if self.windowType == MAKER:
            for key in self.setting:
                self.list.append(xbmcgui.ListItem(key['Name'])) # Personal Lists
            self.list.append(xbmcgui.ListItem('')) # Add Button

        # Lists Selector
        elif self.windowType == LIST:
            names = {}
            if 'Choose' in self.param:
                for key, value in self.param['Choose'].items():
                    names[key] = value

            for key in remoteLists:
                item = xbmcgui.ListItem(key['Name'])
                if len(key['Groups']) > 1 : item.setProperty('groups', 'true')
                if key['Name'] in names and names[key['Name']] == ['*']:
                    self.Choose[key['Name']] = names[key['Name']]
                    item.setProperty('selected', 'selected')
                elif key['Name'] in names:
                    self.Choose[key['Name']] = names[key['Name']]
                    item.setProperty('selected', 'partial')
                else: item.setProperty('selected', 'unselected')
                self.list.append(item)

        # Groups Selector
        elif self.windowType == GROUPS:
            # import web_pdb;web_pdb.set_trace()
            if self.param[0] == ['*']:
                for k in self.param[1]:
                    item = xbmcgui.ListItem(k['Name'])
                    item.setProperty('selected', 'selected')
                    self.Groups.append(k['Id'])
                    self.list.append(item)
            else:
                for k in self.param[1]:
                    item = xbmcgui.ListItem(k['Name'])
                    if k['Id'] in self.param[0]:
                        item.setProperty('selected', 'selected')
                        self.Groups.append(k['Id'])
                    else:
                        item.setProperty('selected', 'unselected')
                    self.list.append(item)

        self.loadList(0)

    def onClick(self, control):
        logger.debug('CONTROL', control)
        focus = self.getFocusId()
        if control == MAKER:
            pos = self.List.getSelectedPosition()
            selection = self.List.getListItem(pos)
            name = xbmcgui.Dialog().input(config.getString(30011), selection.getLabel())
            if not name: name = 'Lista {}'.format(len(self.setting) + 1)
            item = xbmcgui.ListItem(name)
            if not selection.getLabel():
                self.list.insert(-1, item)
                self.setting.append({'Name':name})
            else:
                self.list[pos] = item
                self.setting[pos] = {'Name':name, 'Choose':self.setting[pos].get('Choose',[])}
            self.save()
            Choose = launch(LIST, self.setting[pos])
            if Choose:
                self.setting[pos] = {'Name':name, 'Choose':Choose}
            else:
                self.setting.pop(pos)
                self.list.pop(pos)

            self.save()
            self.loadList(pos)

        elif control == LIST:
            pos = self.List.getSelectedPosition()
            selection = self.List.getListItem(pos)
            if selection.getProperty('selected') != 'selected':
                selection.setProperty('selected', 'selected')
                self.Choose[selection.getLabel()] = ['*']
            else:
                selection.setProperty('selected', 'unselected')
                del self.Choose[selection.getLabel()]
            self.loadList(pos)

        elif control == OPTIONS:
            pos = self.List.getSelectedPosition()
            selection = self.List.getListItem(pos)
            # import web_pdb;web_pdb.set_trace()
            for key in remoteLists:
                if key['Name'] == selection.getLabel():
                    self.Groups = launch(GROUPS, [self.Choose[selection.getLabel()] if selection.getLabel() in self.Choose else [], key['Groups']])
                    if len(self.Groups) == len(key['Groups']):
                        selection.setProperty('selected', 'selected')
                        self.Choose[selection.getLabel()] = ['*']
                    elif self.Groups:
                        selection.setProperty('selected', 'partial')
                        self.Choose[selection.getLabel()] = self.Groups
                    else:
                        selection.setProperty('selected', 'unselected')
                        self.Choose[selection.getLabel()] = []
            # import web_pdb;web_pdb.set_trace()
            for n, item in enumerate(self.setting):
                if selection.getLabel() == item['Name']:
                    self.setting[pos]['Choose'] = self.Choose
            self.save()
            self.loadList(pos)

        elif control == GROUPS:
            pos = self.List.getSelectedPosition()
            selection = self.List.getListItem(pos)
            Id = self.param[1][pos]['Id']
            if selection.getProperty('selected') != 'selected':
                selection.setProperty('selected', 'selected')
                self.Groups.append(Id)
            else:
                selection.setProperty('selected', 'unselected')
                self.Groups.remove(Id)
            self.loadList(pos)

        elif control in [MU]:
            p1 = self.List.getSelectedPosition()
            p2 = p1 - 1
            if p2 > -1:
                self.list[p1], self.list[p2] = self.list[p2], self.list[p1]
                self.setting[p1], self.setting[p2] = self.setting[p2], self.setting[p1]
                self.save()
                self.loadList(p2, MU)

        elif control in [MD]:
            p1 = self.List.getSelectedPosition()
            p2 = p1 + 1
            if p2 < len(self.list) - 1:
                self.list[p1], self.list[p2] = self.list[p2], self.list[p1]
                self.setting[p1], self.setting[p2] = self.setting[p2], self.setting[p1]
                self.save()
                self.loadList(p2, MD)

        elif control in [DELETE]:
            pos = self.List.getSelectedPosition()
            self.list.pop(pos)
            self.setting.pop(pos)
            self.save()
            self.loadList(pos)



        elif control in [BACK]:
            self.close()

    def onAction(self, action):
        action = action.getId()
        if action in [EXIT, BACKSPACE]:
            self.close()

    def loadList(self, pos, button = None):
        self.List.reset()
        self.List.addItems(self.list)
        self.setFocusId(self.windowType)
        self.List.selectItem(pos)
        if button:
            self.setFocusId(button)

    def save(self):
        config.setSetting(utils.PARAM_LIST_NAME, json.dumps(self.setting))

def launch(windowType = MAKER, param = None):
    return ListMaker('ListMaker.xml', config.ADDONPATH, 'Default').start(windowType=windowType, param=param)
launch()

