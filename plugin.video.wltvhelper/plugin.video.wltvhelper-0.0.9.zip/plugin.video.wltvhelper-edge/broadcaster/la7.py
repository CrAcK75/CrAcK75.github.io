# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config
from time import time

DRM = 'com.widevine.alpha'
key_widevine = "https://la7.prod.conax.cloud/widevine/license"
host = 'https://www.la7.it'
headers = {
    'host_token': 'pat.la7.it',
    'host_license': 'la7.prod.conax.cloud',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
    'accept': '*/*',
    'accept-language': 'en,en-US;q=0.9,it;q=0.8',
    'dnt': '1',
    'te': 'trailers',
    'origin': 'https://www.la7.it',
    'referer': 'https://www.la7.it/',
}

def play(search):
    res=[]
    if search == 'La7': url = 'https://www.la7.it/dirette-tv'
    elif search == 'La7d': url = 'https://www.la7.it/live-la7d'
    data = requests.get(url).text
    if not config.getSetting('mpd'):
        video_urls = []
        qualities = []
        uri = scrapers.find_single_match(data, r'''["]?m3u8["]?\s*:\s*["']([^"']+)["']''')
        data = requests.get(uri).text
        urls = scrapers.find_multiple_matches(data, r'RESOLUTION=(\d+x\d+)')
        for quality in urls:
            q = quality.split('x')[0]
            if quality not in qualities:
                qualities.append(q)
                video_urls.append([q, uri.replace('.m3u8', '_{}_.m3u8'.format(quality))])
        video_urls.sort(key=lambda url: int(url[0]))
        if video_urls:
            res = [video_urls[config.quality(qualities)][-1]]

    else:
        preurl = scrapers.find_single_match(data, r'preTokenUrl = "(.+?)"')
        uri = scrapers.find_single_match(data, r'''["]?dash["]?\s*:\s*["']([^"']+)["']''')        

        if uri:
            tokenHeader = {
                'host': headers['host_token'],
                'user-agent': headers['user-agent'],
                'accept': headers['accept'],
                'accept-language': headers['accept-language'],
                'dnt': headers['dnt'],
                'te': headers['te'],
                'origin': headers['origin'],
                'referer': headers['referer'],
            }

            preAuthToken = requests.get(preurl, headers=tokenHeader,verify=False).json()['preAuthToken']

            licenseHeader = {
                'host': headers['host_license'],
                'user-agent': headers['user-agent'],
                'accept': headers['accept'],
                'accept-language': headers['accept-language'],
                'preAuthorization': preAuthToken,
                'origin': headers['origin'],
                'referer': headers['referer'],
            }

            preLic= '&'.join(['%s=%s' % (name, value) for (name, value) in licenseHeader.items()])
            tsatmp=str(int(time()))
            license_url= key_widevine + '?d=%s'%tsatmp
            lic='%s|%s|R{SSM}|'%(license_url, preLic)
            res=[uri, lic, DRM]

    return res