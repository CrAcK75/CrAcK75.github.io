# -*- coding: utf-8 -*-
import requests
from lib import scrapers, config, logger

host = 'https://www.paramountnetwork.it'
def play(search):
    res = []
    qualities = []
    video_urls = []
    url = ''
    data = requests.get(host).text
    matches = scrapers.find_multiple_matches(data, r'(/diretta-tv/[^"]+)"[^>]+>([^ ]+)')
    for url, title in matches:
        if title == search:
            url = host + url
            break
    if url:
        data = requests.get(url).text
        mgid = scrapers.find_single_match(data, r'uri":"([^"]+)"')
        url = 'https://media.mtvnservices.com/pmt/e1/access/index.html?uri=' + mgid + '&configtype=edge&ref=' + url
        data = requests.get(url).text
        ID = scrapers.find_single_match(data, r'"id":"([^"]+)"')
        url = scrapers.find_single_match(data, r'brightcove_mediagenRootURL":"([^"]+)"')
        url = requests.get(url.replace('&device={device}','').format(uri = ID)).json()['package']['video']['item'][0]['rendition'][0]['src']
        # res =[url.split('?')[0]]
        data = requests.get(url).text.replace('\n', ' ').replace('\t', ' ')
        urls = scrapers.find_multiple_matches(data, r'RESOLUTION=(\d+x\d+).*?(http[^ ]+)')
        for quality, url in urls:
            quality = quality.split('x')[0]
            if quality not in qualities:
                qualities.append(quality)
                video_urls.append([quality, url])
        video_urls.sort(key=lambda url: int(url[0]))

    if video_urls: res = [video_urls[config.quality(qualities)][-1]]
    logger.debug('RES',data)
    return res