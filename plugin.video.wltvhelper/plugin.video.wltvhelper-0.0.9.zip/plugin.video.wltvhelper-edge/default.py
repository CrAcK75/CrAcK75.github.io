# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# XBMC entry point
# ------------------------------------------------------------

import os, sys, xbmc, xbmcaddon, xbmcgui, xbmcplugin
# ADDON = xbmcaddon.Addon(id='plugin.video.wltvhelper')
# if sys.version_info[0] >= 3:
#     import xbmcvfs
#     from xbmcvfs import translatePath
# else:
#     from xbmc import translatePath
# config.ADDONPATH = translatePath(ADDON.getAddonInfo('Path'))
# lib = translatePath(os.path.join(config.ADDONPATH, 'lib'))
# sys.path.insert(0, lib)

from lib.install import install
from lib import logger, config

PY3 = True if sys.version_info[0] >= 3 else False

if sys.argv[2] and 'play' in sys.argv[2]:
    sp = sys.argv[2].split('/')
    if len(sp) == 3:
        broadcaster=sp[1]
        channel=sp[2]
    c = __import__('broadcaster.' + broadcaster, None, None, ['broadcaster.' + broadcaster])
    res = c.play(channel)

    if res:
        xlistitem = xbmcgui.ListItem(path=res[0])
        logger.debug('Play: ', res[0])
        if len(res) == 3:
            install()
            xlistitem.setProperty('inputstream' if PY3 else 'inputstreamaddon', 'inputstream.adaptive')
            xlistitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            xlistitem.setProperty("inputstream.adaptive.license_type", res[2])
            xlistitem.setProperty("inputstream.adaptive.license_key", res[1])
            xlistitem.setMimeType('application/dash+xml')


        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xlistitem)

elif sys.argv[2] and 'install' in sys.argv[2]:
    install()
elif sys.argv[2] and 'switch' in sys.argv[2]:
    from lib import switcher
    switcher
elif sys.argv[2] and 'maker' in sys.argv[2]:
    from lib import listmaker
    listmaker
elif sys.argv[2] and 'setting' in sys.argv[2]:
    config.openSettings()
else:
    handle = int(sys.argv[1])
    li = xbmcgui.ListItem(config.getString(30010))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?maker', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(config.getString(30002))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?switch', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(config.getString(30003))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?setting', listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)


