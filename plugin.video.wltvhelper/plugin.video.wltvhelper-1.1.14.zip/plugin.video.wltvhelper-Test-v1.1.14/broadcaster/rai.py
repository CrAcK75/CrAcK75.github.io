# -*- coding: utf-8 -*-

import requests

def play(search):
    res = {}
    url = ''
    requrl = 'https://www.raiplay.it/dirette.json'
    json = requests.get(requrl).json()['contents']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['content_url']
            break
    if url:
        res['url'] = url
        res['manifest'] = 'hls'
    return res
